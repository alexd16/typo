Date.weekdays = $w('Må Ti On To Fr Lö Sö');
Date.months = $w('Januari Februari Mars April Maj Juni Juli Augusti September Oktober November December');
Date.first_day_of_week = 1;
_translations = {
  "OK": "OK",
  "Now": "Nu",
  "Today": "Idag",
  "Clear": "Avbryt"
}