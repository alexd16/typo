require 'sidebar'
require '<%= file_name %>'

<%= class_name %>.view_root = File.dirname(__FILE__) + '/views'
